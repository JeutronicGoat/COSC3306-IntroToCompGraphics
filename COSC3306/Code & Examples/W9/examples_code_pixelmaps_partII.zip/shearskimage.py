#Program that demonstrateds how do do image shearing.
#Written by Miguel Garcia-Ruiz
from skimage import io #Using skinmage library for doing shearing: http://scikit-image.org/docs/dev/api/skimage.transform.html#skimage.transform.AffineTransform
from skimage import transform as tf

# Load the image:
image = io.imread("lava.png")

# Create Afine transform
afine_tf = tf.AffineTransform(shear=-0.2)

# Apply transform to image data
modified = tf.warp(image, afine_tf)

# Save resulting image and display the result
io.imshow(modified)
io.show() 

