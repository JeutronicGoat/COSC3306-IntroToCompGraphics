#Demonstrating scaling transformation using a pixelmap
#Writen by Miguel Garcia-Ruiz
from PIL import Image

#Manipulate image (image transformation):
#Open image and scale it down to 128x128 pixels:
im = Image.open("lava.png")
im=im.resize((128,128),resample=1)
#Parameters:	
#size: The requested size in pixels, as a 2-tuple: (width, height).
#resample: An optional resampling filter. This can be one of PIL.Image.NEAREST (use nearest neighbour), 
#PIL.Image.BILINEAR (linear interpolation), PIL.Image.BICUBIC (cubic spline interpolation), or PIL.Image.LANCZOS (a high-quality downsampling filter). 
#If omitted, or if the image has mode '1' or 'P', it is set PIL.Image.NEAREST.
#resample=0 is for NEAREST, 
#resample=1 is for BILINEAR
#resample=2 is for BICUBIC
#resample=3 is for LANCZOS

#Output the result  to screen and save it as a file:
im.save("lava128x128.png","PNG")
im.show("lava128x128.png")




