#Program that rotates a bitmap.
#Writen by Miguel Garcia-Ruiz
from PIL import Image  #Pillow library

#Manipulate image (image transformation):
#Open image generated and saved in the above step and rotate it by 45 degrees:
im = Image.open("chessboard.png")
im=im.rotate(45) #rotates image by 45 degrees.

#Output the result  to screen and save it as a file:
im.save("chessboardrotated.png","PNG")
im.show("chessboardrotated.png")




