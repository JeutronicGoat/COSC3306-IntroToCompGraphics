#Description of digital image processing steps using a bitmap.
#Writen by Miguel Garcia-Ruiz
from PIL import Image, ImageDraw
#import Image, ImageDraw
from itertools import cycle

###################################################################
#Step 1: Generate bitmap procedurally (chessboard):

#Modified from: http://wordaligned.org/articles/drawing-chessboards
n=8
pixel_width=200

def sq_start(i):
   "Return the x/y start coord of the square at column/row i."
   return i * pixel_width / n
    
def square(i, j):
   "Return the square corners, suitable for use in PIL drawings" 
   return map(sq_start, [i, j, i + 1, j + 1])
    
image = Image.new("L", (pixel_width, pixel_width))
draw_square = ImageDraw.Draw(image).rectangle
squares = (square(i, j)
          for i_start, j in zip(cycle((0, 1)), range(n))
          for i in range(i_start, n, 2))
for sq in squares:
     draw_square(sq, fill='white')
image.save("chessboard.png")


###################################################################
#Step 2: Manipulate image (image transformation):
#Open image generated and saved in the above step and rotate it by 45 degrees:
im = Image.open("chessboard.png")
im=im.rotate(45)


###################################################################
#Step 3: Output the result  to screen and save it as a file:
im.save("chessboardrotated.png","PNG")
im.show("chessboardrotated.png")




