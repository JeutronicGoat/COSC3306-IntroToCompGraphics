from PIL import Image
#it converts the image to 1-bit (bitmap) image using Floyd-Steinberg dithering algorithm by default:
#im = Image.open("lena.bmp").convert('1').save("lenadither.png","PNG")

#It converts the image to 8 bits (raster image) using Floyd-Steinberg dithering algorithm and using a standard 216-colour Web palette:
im = Image.open("lena.bmp").convert("P", dither=Image.FLOYDSTEINBERG, palette=Image.WEB, colors=216 ).save("lenadither.png","PNG")

