from PIL import Image
im = Image.open("lena.bmp").rotate(45).convert('LA').save("lenabw.png","PNG")
