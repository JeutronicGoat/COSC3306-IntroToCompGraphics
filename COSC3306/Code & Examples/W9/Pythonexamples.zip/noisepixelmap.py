#Program that creates a pixelmap image with random noise. 
#As seen in: http://stackoverflow.com/questions/10901049/create-set-of-random-jpgs
import numpy#numpy is a math processing library. 
from PIL import Image #PIL is the Pillow library.
a = numpy.random.rand(600,800,3)*255 # generates a matrix of random numbers (height,width, RGB)
#img = Image.fromarray(a.astype('uint8')).convert('1') #this is for generating a bitmap (black and white)
img = Image.fromarray(a.astype('uint8'))
img.save('pixelmap.png','PNG')
img.show()

