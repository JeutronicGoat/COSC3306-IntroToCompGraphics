from PIL import Image
im = Image.open("chessboard.png").rotate(45).convert('RGB').save("example.png","PNG")

