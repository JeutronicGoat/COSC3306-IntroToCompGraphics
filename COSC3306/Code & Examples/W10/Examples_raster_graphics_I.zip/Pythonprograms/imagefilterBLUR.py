from PIL import Image, ImageFilter
im = Image.open("lena.bmp").filter(ImageFilter.BLUR).save("lenablur.png","PNG") 
