from PIL import Image, ImageFilter
#Blur filter
#http://pillow.readthedocs.org/en/3.1.x/reference/ImageFilter.html
#Example of convolution matrix:
#edge detection filter:
#im = Image.open("lena.bmp").filter(ImageFilter.Kernel((3,3), (-1, -1, -1, -1, 8, -1, -1, -1, -1), scale=None, offset=0)).save("lenaEDGEKERNEL.png","PNG") 
#Sharpen filter:
im = Image.open("lena.bmp").filter(ImageFilter.Kernel((3,3), (0,-1,0,-1,5,-1,0,-1,0), scale=None, offset=0)).save("lenaSHARPENKERNEL.png","PNG") 
#Box blur:
#im = Image.open("lena.bmp").filter(ImageFilter.Kernel((3,3), (0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1), scale=None, offset=0)).save("lenaBLURKERNEL.png","PNG")

 
