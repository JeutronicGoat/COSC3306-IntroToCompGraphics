from PIL import Image, ImageFilter
#EDGES filter
#http://pillow.readthedocs.org/en/3.1.x/reference/ImageFilter.html
#Contour filter:
im = Image.open("lena.bmp").filter(ImageFilter.FIND_EDGES).save("lenaEDGES.png","PNG") 
