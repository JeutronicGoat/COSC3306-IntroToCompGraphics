from PIL import Image, ImageFilter
#Blur filter
#http://pillow.readthedocs.org/en/3.1.x/reference/ImageFilter.html
#Contour filter:
im = Image.open("lena.bmp").filter(ImageFilter.EMBOSS).save("lenaemboss.png","PNG") 
